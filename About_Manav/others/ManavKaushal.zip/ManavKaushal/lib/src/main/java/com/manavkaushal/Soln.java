package com.manavkaushal;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.NoSuchFileException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;


import com.google.gson.Gson;

/*
 *  Author      : MANAV KAUSHAL
 *  Contact     : +91 9833080299
 *  Email       : manavdkaushal@gmail.com
 *  Location    : Mumbai, INDIA
 *  Released on : 25.May.2024
 *  Application : Transposition of Piano Key Notes based on semitone provided.
 *  Parameters  : Three parameters are required, neither less nor more.   
 *  Usage       : java -jar manavtask.jar in/a.json 5 out/b.json
 *  Result      : Based on input key notes provided in inputFile and no. of semitones to adjust as pitch, 
 *                output notes are written into outFile. 
 * */

public class Soln 
{
	public static  String inputFile, outputFile, result;
	public static  int semitone;
	public static  String[][] inpNotes;
	public static  String[] outNotes;
	public static  LinkedHashMap<String, Integer> noteMap = new LinkedHashMap<String, Integer>();
	public static  LinkedHashMap<Integer, String> posMap  = new LinkedHashMap<Integer, String>();
	
	
	// MAIN method of Solution class to execute the required steps for Input, Transposition and Output
	public static void main(String[] args)  
	{
		if( args != null   &&  args.length == 3) 
		{
			inputFile  = args[0];
			outputFile = args[2];
			
			try {   
				semitone   = Integer.parseInt(args[1]);  
			}catch(Exception e) {
				sop("\n Invalid integer value provided for Semitone at arg[2], Cannot continue");
				return;
			}
			
			if( outputFile != null )
				deleteOutFile();
			
			if( inputFile != null )
				inpNotes = getInputNotes();
			
			if( inpNotes != null )
				outNotes = getOutputNotes();
			
			if( outNotes != null)
				result   = writeOutputFile();
			
			if( result != null ) {
				sop("\n ===== SUCCESS : Transposition with semitone "+ semitone +" completed. ===== ");
				sop("\n Output File : "+result);
			} else {
				sop("\n ----- FAILURE : Transposition failed due to an error. ----- ");
			}
			
			noteMap = null;
			posMap  = null;
			return;
			
		} 
		else {
			sop("\n Please provide required 3 parameters to proceed ( inputFile,  semitone,  outputFile )");
			return;
		}
	}
	
	//Method to delete existing outputFile to evade any confusion
	public static void deleteOutFile() {
		String currDir      = new File(".").getAbsolutePath();
		String fullFilePath = currDir.substring(0,currDir.length()-1) + outputFile;
		fullFilePath        = fullFilePath.replaceAll("\\\\", "/");
		File outFile        = null;
		
		try {
			outFile = new File(fullFilePath);
			if( outFile.exists() )
				outFile.delete();
		} catch (Exception e) {
			sop("\n");
		}
	}
	
	// Method to write output notes on the provided outFilePath 
	public static String writeOutputFile() 
	{
		String outStr       = Arrays.toString(outNotes) ;		
		String currDir      = new File(".").getAbsolutePath();
		String fullFilePath = currDir.substring(0,currDir.length()-1) + outputFile;
		fullFilePath        = fullFilePath.replaceAll("\\\\", "/");
		File outFile        = null;
		FileWriter fw;
		BufferedWriter bw;
		
		try {
			outFile = new File(fullFilePath);
			fw      = new FileWriter(outFile);
			bw      = new BufferedWriter(fw);
			bw.write(outStr);
			bw.close();

			return fullFilePath;
			
		} catch (Exception e) {
			sop("\n ERROR : Failed to write output file, invalid path");			
		} finally {
			bw = null;
			fw = null;
		}		
		return null;
	}
	

	public static String[] getOutputNotes() 
	{
		String[] pOutNotes = new String[inpNotes.length];
		String note, rslt;
		
		int inNoteLoc, trnps, c = 0;
		
		for( String[] inpNote : inpNotes ) 
		{
			note = Arrays.toString(inpNote);
			rslt = transpose(note, semitone);
			
			if( rslt != null ) 
			{
				if( rslt.equals("INVALID") ) 
				{
					sop("\n ERROR : Input note '"+ note +"' does not exist on Piano keyboard, Cannot generate output file.");
					return null;
				} 
				else if( rslt.equals("OUTSIDE") ) 
				{
					sop("\n ERROR : Transposition resulting into note that falls outside keyboard, Cannot generate output file.");
					return null;
				} 
				else 
				{
					pOutNotes[c++] = rslt;					
				} 
			} else {
				sop("\n ERROR : Transposition error occured.");
				return null;
			}
		
		}
		return pOutNotes;
	}
	
	// Method to transpose pitch UP / DOWN based on inputNote & semitone value provided
	public static String transpose(String pInpNote, int pSemitone) 
	{
		int inNoteLoc, trnps;
		String toReturn = null;
	
		if(noteMap.containsKey(pInpNote) ) 
		{
			inNoteLoc = noteMap.get(pInpNote); // locate the input Note and get its position on Piano Keyboard
			trnps     = inNoteLoc + pSemitone; // if positive semitone given then pitch will go UP, else if negative semitone then pitch is DOWN
			
			if( posMap.containsKey(trnps) ) {  // SUCCESS - After transposition the new Note exists on Keyboard.
				toReturn = posMap.get(trnps); 
			} else { 
				toReturn = "OUTSIDE";          // FAILURE - After transposition the new Note falls out of Keyboard.
			}
		} else {
			toReturn = "INVALID";              // FAILURE - Input Note does not exist in the Piano Keyboard.
		}
		return toReturn;
	}
	
	// Method to read the input JSON file and convert json text into java structure to work on.
	public static String[][] getInputNotes() 
	{
		String inpJson = getJsonFromInpFile();
		if( inpJson != null ) {
			inpNotes = jsonToStrArr(inpJson);
			return inpNotes;
		} else {
			sop("\n Error reading input json file / file is blank");
			return null;
		}
	}
	
	
	// Method to convert JSON string into double dimension String[][]
	public static String[][] jsonToStrArr(String jsn) {		
		Gson gson     = new Gson();
		String[][] nt = null;
		
		try {
			nt = gson.fromJson(jsn, String[][].class);
		} catch (Exception e) {
			sop("\n Error : Invalid json string in Input File.");
		}
		gson          = null;
		
		return nt;
	}
	
	
	// Method to read json data as string from supplied File path
	public static String getJsonFromInpFile() {
		String jsonStr = null;
		
		String txt, currDir = new File(".").getAbsolutePath();
		String fullFilePath = currDir.substring(0,currDir.length()-1) + inputFile;
		fullFilePath        = fullFilePath.replaceAll("\\\\", "/");
		File file           = null;
		FileReader fr;
		BufferedReader br;
		StringBuffer sb; 
		
		try 
		{
			file = new File(fullFilePath);
			fr   = new FileReader(file);
			br   = new BufferedReader(fr);
			sb   = new StringBuffer();
			     
	        while ((txt = br.readLine()) != null)
	            sb.append(txt);
	        
			jsonStr = sb.toString();
			jsonStr = jsonStr.replaceAll("\\s", "").replace("\\n", "").replace("\\r", "");
			br.close();
			
		} catch (NoSuchFileException nsfe) {
			sop("\n Invalid / Unable to access path - '" + fullFilePath + "'");
			return null;
		} catch( Exception e) {
			sop("\n Error reading data from File "+ fullFilePath + "\n\n");
			return null;
		} finally {
			br = null;
			fr = null;
			sb = null;
		}
		
		return jsonStr;
	}
	
	
	// Shortcut utility method written to print console logs.
	public static void sop(Object obj) {
		System.out.println(obj);
	}
	
	
	
	// Static block to populate Piano Keyboard data as a Map to work on later. 
	static 
	{
		int octave = 0;
		int notnum = 0;
		int i = 1;
		String note;
		
		while( i <= 88 ) 
		{
			if( i == 1 ) { //      // Octave -3
				octave = -3;
				notnum = 10;
			} else if( i == 4 ) {  // Octave -2
				octave = -2;
				notnum = 1;
			} else if( i == 16 ) { // Octave -1
				octave = -1;
				notnum = 1;
			} else if( i == 28 ) { // Octave 0
				octave = 0;
				notnum = 1;
			} else if( i == 40 ) { // Octave 1
				octave = 1;
				notnum = 1;
			} else if( i == 52 ) { // Octave 2
				octave = 2;
				notnum = 1;
			} else if( i == 64 ) { // Octave 3
				octave = 3;
				notnum = 1;
			} else if( i == 76 ) { // Octave 4
				octave = 4;
				notnum = 1;
			} else if( i == 88 ) { // Octave 5
				octave = 5;
				notnum = 1;
			}
			
			note = "["+ octave +", "+ notnum +"]";
			
			noteMap.put( note, i ); // map to store each Piano Note and its position
			posMap.put( i, note ); //  another map to store which Note is at what position
			
			i++;
			notnum++;
		}

		
		/*Iterator<Map.Entry<String, Integer>> itr = noteMap.entrySet().iterator();		
		while(itr.hasNext()) {
			Map.Entry<String, Integer> entry = itr.next();
			sop(entry.getKey() + " -> " + entry.getValue());
		}*/

	}
}
