package com.manavkaushal;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class SolnTest {

	@Test
	public void validTranspose()  {
		String expected = "[-3, 10]";		
		String actual   = Soln.transpose("[-2, 1]", -3);
		
		assertEquals("valid transposed output", expected, actual);
	}
	
	@Test
	public void inValidInputNote()  {
		String expected = "INVALID";		
		String actual   = Soln.transpose("[-2, 14]", -2);
		
		assertEquals("correct message when invalid key provided", expected, actual);
	}
	
	@Test
	public void isOutputNoteOutside()  {
		String expected = "OUTSIDE";		
		String actual   = Soln.transpose("[4, 10]", 4);
		
		assertEquals("correct message when output key is outside keyboard", expected, actual);
	}
	
}
